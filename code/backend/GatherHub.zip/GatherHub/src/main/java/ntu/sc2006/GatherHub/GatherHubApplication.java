package ntu.sc2006.GatherHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatherHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatherHubApplication.class, args);
	}

}
