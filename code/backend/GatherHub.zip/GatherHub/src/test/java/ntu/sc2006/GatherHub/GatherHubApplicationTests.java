package ntu.sc2006.GatherHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatherHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
